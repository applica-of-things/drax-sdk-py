# draxsdk
Python SDK for Drax platform

### Installation 
To install the package you need to run the following command:

`$ python3 -m pip install --index-url https://test.pypi.org/simple/ --no-deps draxsdk`

### Usage 
Import drax SDK module in your code:
```python
from draxsdk import drax

```
