# draxsdk
Python SDK for Drax platform

### Installation 
To install the package you need to run the following command:

`$ pip install draxsdk`

### Usage 
Import drax SDK module in your code:
```python
from draxsdk import drax

```
